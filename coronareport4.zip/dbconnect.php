<?php

$con = mysqli_connect('localhost', 'admin', 'Sadna5555');
if (mysqli_select_db($con,'corona report'));

?>