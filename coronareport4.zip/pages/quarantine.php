<html>
<body>

<?php
$servername = "localhost:3306";
$username = "romymo_admin";
$password = "Sadna5555";
$dbname = "romymo_corona report";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
} 


$firstname=$_POST["firstname"];
$lastname=$_POST["lastname"];
$id=$_POST["id"];
$email=$_POST["email"];
$street=$_POST["street"];
$hnumber=$_POST["hnumber"];
$city=$_POST["city"];
$bday=$_POST["bday"];
$bmonth=$_POST["bmonth"];
$byear=$_POST["byear"];
$reason=$_POST["reason"];
$day1=$_POST["day1"];
$month1=$_POST["month1"];
$year1=$_POST["year1"];
$day2=$_POST["day2"];
$month2=$_POST["month2"];
$year2=$_POST["year2"];
$comment=$_POST["comment"];
  header('Content-Type: text/html; charset=utf-8');
$sql="INSERT INTO quar (firstname, lastname, id, email, street, hnumber, city, bday, bmonth, byear, reason, day1, month1, year1, day2, month2, year2, comment) VALUES ('$firstname','$lastname','$id','$email','$street','$hnumber','$city','$bday','$bmonth','$byear','$reason','$day1','$month1','$year1','$day2','$month2','$year2','$comment')";
$conn->query("SET NAMES 'utf8'");
$conn->query($sql);
echo $sql;




$conn->close();
?>  
</body>
</html>
