<html>
<body>

<?php
    #   if(isset($_POST['sub']))
{
$servername = "localhost:3306";
$username = "romymo_admin";
$password = "Sadna5555";
$dbname = "romymo_corona report";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
} 



$id=$_POST["id"];
$firstname=$_POST["firstname"];
$lastname=$_POST["lastname"];
$phone=$_POST["phone"];
$age=$_POST["age"];
$daysofsymptoms=$_POST["daysofsymptoms"];
$daysofquarantine=$_POST["daysofquarantine"];
$symptoms=$_POST["symptoms"];
$symp="";
foreach($symptoms as $symp1)
   {
      $symp .= $symp1.",";
   }


  header('Content-Type: text/html; charset=utf-8');
$sql="INSERT INTO symptoms (id, firstname, lastname, phone, age, daysofsymptoms,  daysofquarantine, symptoms) VALUES ('$id','$firstname','$lastname','$phone','$age','$daysofsymptoms','$daysofquarantine','$symptoms')";
$conn->query("SET NAMES 'utf8'");
$conn->query($sql);
echo $sql;




$conn->close();
}
?>  
</body>
</html>
