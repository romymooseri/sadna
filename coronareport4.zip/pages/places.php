<html>

<body>

    <?php

    // TODO: Change the connection info
    $servername = "localhost:3306";
    $username = "romymo_admin";
    $password = "Sadna5555";
    $dbname = "romymo_corona report";

    // TODO: Point in php.ini the mysqli driver
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        error_log("Error connection");
        throw new Exception("error connection");
        die("Connection failed: " . $conn->connect_error);
    }


        

        
    $data = json_decode(stripslashes($_POST['markers']), true);

    foreach ($data as $marker) {
        $lat = $marker['lat'];
        $lng = $marker['lng'];
        $address = $marker['address'];
        $inumber = $marker['inumber'];
        $name= $marker['name'];
        $family= $marker['family'];
 
        $clean_address = str_replace("'", "", $address);

        // TODO: Create table 'locations' with lat and lng (both double), and address VARCHAR(20000)
        $sql = "INSERT INTO locations (lat, lng, address, inumber, name, family)
        VALUES ('$lat', '$lng', '$clean_address','$inumber', '$name', '$family')";

        $conn->query("SET NAMES 'utf8'");
        $conn->query($sql);
        error_log($sql);
    }

    $conn->close();
    ?>
</body>

</html>