<?php

if(isset($_POST["submit"]))
{
$id = $_POST['id'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$phone = $_POST['phone'];
$age = $_POST['age'];
$daysofsymptoms = $_POST['daysofsymptoms'];
$daysofquarantine = $_POST['daysofquarantine'];
$symptoms=$_POST["symptoms"];
$b=implode(",",$symptoms);

    
    if(!empty($id) || !empty($firsname) || !empty($lastname) || !empty($age) || !empty($daysofsymptoms) || !empty($daysofquarantine) || )
    {
        $host = "localhost";
        $dbusername = "admin";
        $dbpassword = "Sadna5555";
        $dbname = "corona report";
        
        //create connection
        $con= new mysqli($host,$dbusername,$dbpassword,$dbname);
        
             if (mysqli_connect_error()){
                 
            
        }

mysql_query("insert into symptoms(id,firstname,lastname,phone,age,daysofsymptoms,daysofquarantine,symptoms)values('$id','$firstname','$lastname','$phone',$age','$daysofsymptoms','$daysofquarantine','$symptoms','$b')");
}
  
    else{
        echo "נא למלא את כל השדות";
        die();
    }
    
}


   <label class="optional">*תעודת זהות
                             </label>
                             <input type="text" class="long" name="id"/>
                         </p>
                         <p>
                             <label>שם פרטי
                             </label>
                             <input type="text" class="long" name="firstname"/>
                         </p>
						 <p>
                             <label>שם משפחה
                             </label>
                             <input type="text" class="long" name="lastname"/>
                         </p>
                         <p>
                                             <label>טלפון                                             </label>
                                             <input type="varchar" class="long" name="phone"/>
                                         </p>
						 <p>
                             <label>גיל
                             </label>
                             <input type="text" maxlength="3" name="age"/>
                         </p>
						  <p>
                             <label>מספר ימים שהנך מרגיש/ה את הסימפטומים
                             </label>
                             <input type="text" maxlength="2" name="daysofsymptoms"/>
                             
                         </p>
                         <p>
                         <label>מספר ימים שהנך בבידוד
                                                 </label>
                                                 <input type="text" maxlength="2" name="daysofquarantine"/>
                         <p>
                             <h1>סמן את הסימפטומים הקיימים</h1>
                             
                             <p>
                             <label> קוצר נשימה <input type= "checkbox" name= "symptoms[]" value= "unbreath" /></label>
                             <label> חום מעל 38  <input type= "checkbox" name= "symptoms[]" value= "fever" /></label>
                             <label>שיעול <input type= "checkbox"  name= "symptoms[]" value= "cough" /></label><br>
                             <label> תסמינים נשימתיים נוספים <input type= "checkbox" name= "symptoms[]" value= "otherbreathissue" /></label>
                                                       <label> עייפות <input type= "checkbox" name= "symptoms[]" value= "tiredness" /></label>
                                                       <label> אובדן חוש הטעם ו/או הריח <input type= "symptoms[]"  name= "tasteorsmell" value= "js1" /></label><br>
                                                       <label>בחילות <input type= "checkbox" name= "symptoms[]" value= "nausea" /></label>
                                                                                                             <label> צינון <input type= "checkbox" name= "symptoms[]" value= "cooling" /></label>
                                                                                                                                                                       <label> אחר <input type= "checkbox" name= "symptoms[]" value= "other" /></label><br>
                                                                                
                            


    

        
   
        
    }
  
    
}